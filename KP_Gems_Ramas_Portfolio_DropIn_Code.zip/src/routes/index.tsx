import * as React from 'react';
import { useState } from 'react';
import { createFileRoute } from '@tanstack/react-router';
import { projects, type AdCategory } from '../data/projects';
import { UGCPerformanceCard } from '../components/UGCPerformanceCard';

export const Route = createFileRoute('/')({
  component: PortfolioHome,
});

const CATEGORIES: AdCategory[] = [
  'All',
  'Hyperrealistic AI UGC',
  'Authority VSL',
  '3D Pixar & Claymation',
  'Cinematic Product & Motion',
];

function PortfolioHome() {
  const [activeCategory, setActiveCategory] = useState<AdCategory>('All');
  const [auditMode, setAuditMode] = useState<'raw' | 'engineered'>('engineered');
  const [formSubmitted, setFormSubmitted] = useState(false);

  const filteredProjects =
    activeCategory === 'All'
      ? projects
      : projects.filter((p) => p.category === activeCategory);

  const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);

    try {
      await fetch('/__forms.html', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(formData as any).toString(),
      });
      setFormSubmitted(true);
      form.reset();
    } catch {
      setFormSubmitted(true);
    }
  };

  return (
    <div className="portfolio-shell">
      {/* Sticky Top Navbar */}
      <header className="navbar">
        <div className="navbar__inner">
          <a href="#top" className="navbar__brand">
            <span className="navbar__dot" />
            KP GEMS RAMAS
          </a>
          <nav className="navbar__links">
            <a href="#work">Ad Vault</a>
            <a href="#pipeline">Character-Lock System</a>
            <a href="#comparison">Why It Converts</a>
            <a href="#contact" className="navbar__cta">
              Order a Test Batch
            </a>
          </nav>
        </div>
      </header>

      <main id="top" className="main-container">
        {/* Hero Section */}
        <section className="hero">
          <div className="hero__badge">
            AI Video Editor & Direct-Response Creative Strategist • Available Immediately
          </div>

          <h1 className="hero__title">
            High-Converting <span className="text-accent">AI UGC, Authority VSLs & 3D Ads</span>{' '}
            Engineered to Scale DTC ROAS.
          </h1>

          <p className="hero__subtitle">
            I combine behavioral direct-response scripting with a strict{' '}
            <strong>100% character- and product-lock system</strong>, unretouched matte skin
            physics, and natural ElevenLabs Speech-to-Speech direction—delivering 8 to 12
            scroll-stopping Meta & TikTok ads per week.
          </p>

          <div className="hero__actions">
            <a href="#work" className="btn btn--primary">
              Watch Winning Ads
            </a>
            <a href="#contact" className="btn btn--secondary">
              Book a Paid Test Edit (24h Turnaround)
            </a>
          </div>

          {/* Key Proof Bar */}
          <div className="proof-grid">
            {[
              {
                value: '4,881+',
                label: 'Organic Views & Official TikTok Shop Ad Pick (VENTI ABSOLU)',
              },
              {
                value: '3.73% CTR',
                label: '138 Clicks & 6 Sales Generated in a Single 7-Day Sprint',
              },
              {
                value: '8–12 Ads/Wk',
                label: '24–30h Standard Turnaround (12-Hour Rush Available)',
              },
              {
                value: '100% Lock',
                label: 'Zero Character Morphing & True-to-Life Product Packaging',
              },
            ].map((stat) => (
              <div key={stat.label} className="proof-card">
                <div className="proof-card__value">{stat.value}</div>
                <div className="proof-card__label">{stat.label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Portfolio Filter & Bento Grid */}
        <section id="work" className="section">
          <div className="section__header">
            <div>
              <span className="section__eyebrow">Direct-Response Ad Vault</span>
              <h2 className="section__title">Proven Creative Formats That Beat Control Ads</h2>
            </div>
            <p className="section__desc">
              Click any vertical reel to unmute and replay from 0:00. Organized by exact ad format
              from my production vault.
            </p>
          </div>

          <div className="filter-bar" role="tablist" aria-label="Ad category filter">
            {CATEGORIES.map((category) => {
              const active = activeCategory === category;
              return (
                <button
                  key={category}
                  role="tab"
                  aria-selected={active}
                  onClick={() => setActiveCategory(category)}
                  className={`filter-btn ${active ? 'filter-btn--active' : ''}`}
                >
                  {category}
                </button>
              );
            })}
          </div>

          <div className="bento-grid">
            {filteredProjects.map((project) => (
              <UGCPerformanceCard key={project.id} project={project} />
            ))}
          </div>
        </section>

        {/* Raw AI vs. Engineered Direct-Response Interactive Comparison */}
        <section id="comparison" className="section">
          <div className="section__header">
            <div>
              <span className="section__eyebrow">Quality Diagnostic</span>
              <h2 className="section__title">
                Generic Out-of-the-Box AI vs. Engineered Direct-Response Production
              </h2>
            </div>
            <div className="toggle-pill">
              <button
                type="button"
                onClick={() => setAuditMode('raw')}
                className={`toggle-pill__btn ${auditMode === 'raw' ? 'toggle-pill__btn--active' : ''}`}
              >
                ❌ Generic Raw AI Output
              </button>
              <button
                type="button"
                onClick={() => setAuditMode('engineered')}
                className={`toggle-pill__btn ${
                  auditMode === 'engineered' ? 'toggle-pill__btn--active' : ''
                }`}
              >
                ⚡ My Engineered Production
              </button>
            </div>
          </div>

          <div className="comparison-panel">
            {auditMode === 'raw' ? (
              <div className="comparison-grid comparison-grid--raw">
                <div className="comparison-item">
                  <h3>1. Plastic Skin & Uncanny Lip-Sync</h3>
                  <p>
                    Over-smoothed waxy textures, floating jaws, and mismatched bilabial consonants
                    (M/B/P) scream "fake AI" within 1.5 seconds, tanking viewer trust and
                    Thumbstop Rate.
                  </p>
                </div>
                <div className="comparison-item">
                  <h3>2. Robotic Text-to-Speech Cadence</h3>
                  <p>
                    Flat, monotonous TTS reads with unnatural pauses fail to build emotional tension
                    or urgency, causing massive mid-roll viewer drop-off before the offer reveal.
                  </p>
                </div>
                <div className="comparison-item">
                  <h3>3. Hallucinated Product Labels</h3>
                  <p>
                    Characters morph between shots and product bottles warp or scramble brand logos,
                    making the ad unusable for paid Meta or TikTok Shop compliance.
                  </p>
                </div>
              </div>
            ) : (
              <div className="comparison-grid comparison-grid--engineered">
                <div className="comparison-item">
                  <h3>1. Unretouched Matte Skin & Bilabial Lock</h3>
                  <p>
                    Natural pore texture, realistic iPhone handheld micro-shake, and frame-accurate
                    bilabial jaw kinematics engineered across Higgsfield, Arcads, and Veo 3.1.
                  </p>
                </div>
                <div className="comparison-item">
                  <h3>2. Directed Speech-to-Speech (STS) Prosody</h3>
                  <p>
                    Human guide-track vocal direction in ElevenLabs with micro-breaths, tonal
                    inflections, custom Suno musical hooks, and layered CapCut Pro sound design.
                  </p>
                </div>
                <div className="comparison-item">
                  <h3>3. 100% Character & Product Consistency</h3>
                  <p>
                    Multi-angle Nano Banana 2.1 + Google Flow Omni reference locking keeps the exact
                    same creator ("Kim", Pharmacist avatar, or 3D character) and crisp product label
                    across every scene.
                  </p>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* 4-Step Production Pipeline */}
        <section id="pipeline" className="section">
          <span className="section__eyebrow">24–30 Hour Turnaround System</span>
          <h2 className="section__title">My 4-Stage Modular AI Ad Pipeline</h2>

          <div className="pipeline-grid">
            {[
              {
                step: '01',
                title: 'Hook Diagnostics & Script Architecture',
                desc: 'Isolating Thumbstop (3s) and Hold Rate (15s) bottlenecks using direct-response frameworks (Problem-Agitation, Medical Authority, or Pattern-Interrupt 3D).',
                tools: 'Claude • Gemini • Direct-Response Hook Matrix',
              },
              {
                step: '02',
                title: 'Character & Product Reference Locking',
                desc: 'Generating multi-angle character sheets and exact product packaging plates so visuals remain 100% consistent from frame one to final CTA.',
                tools: 'Nano Banana 2.1 • Google Flow Omni • OpenArt',
              },
              {
                step: '03',
                title: 'Kinematics, 3D Motion & STS Voice Direction',
                desc: 'Animating avatars and 3D Pixar/Claymation scenes paired with emotionally paced ElevenLabs Speech-to-Speech voiceovers and custom Suno song hooks.',
                tools: 'Higgsfield • Veo 3 • Arcads • HeyGen • ElevenLabs • Suno',
              },
              {
                step: '04',
                title: 'Retention Editing, SFX & 1080p Delivery',
                desc: 'Tightening pacing every 1.5–2 seconds with dynamic captions, keyframed B-roll, LUFS-normalized audio, and fast-loading 1080p masters.',
                tools: 'CapCut Pro • Premiere Pro • FFmpeg Faststart',
              },
            ].map((item) => (
              <div key={item.step} className="pipeline-card">
                <div className="pipeline-card__step">{item.step}</div>
                <h3 className="pipeline-card__title">{item.title}</h3>
                <p className="pipeline-card__desc">{item.desc}</p>
                <div className="pipeline-card__tools">{item.tools}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Contact / Test Batch Booking Section (Wired to Netlify __forms.html) */}
        <section id="contact" className="section contact-section">
          <div className="contact-grid">
            <div>
              <span className="section__eyebrow">Scale Your Creative Volume</span>
              <h2 className="section__title">
                Ready to Test 8–12 High-Converting AI Ads Per Week?
              </h2>
              <p className="contact-lead">
                Available immediately for full-time or retainer roles during Philippine & US/EU
                overlap hours. Backed by reliable fiber internet (110 Mbps down / 56 Mbps up) and a
                24–30 hour standard turnaround (12-hour rush for AI UGC).
              </p>

              <div className="rate-cards">
                <div className="rate-card">
                  <div className="rate-card__title">Part-Time Retainer (20 hrs/wk)</div>
                  <div className="rate-card__price">$800 / month</div>
                  <div className="rate-card__meta">
                    8–12 ad-ready 30s edits or 5–7 from-scratch AI concepts/wk
                  </div>
                </div>
                <div className="rate-card rate-card--featured">
                  <div className="rate-card__title">Full-Time Dedicated (40 hrs/wk)</div>
                  <div className="rate-card__price">$1,600 – $2,500 / month</div>
                  <div className="rate-card__meta">
                    Full daily creative pipeline, rapid hook testing & priority 12h rush
                  </div>
                </div>
              </div>

              <div className="direct-contact">
                <div>
                  <strong>Email:</strong>{' '}
                  <a href="mailto:dgems41@gmail.com">dgems41@gmail.com</a>
                </div>
                <div>
                  <strong>Phone / WhatsApp:</strong> +63 930 603 2659
                </div>
                <div>
                  <strong>Telegram:</strong> @wokietokies • <strong>TikTok:</strong> @lumiere_898
                </div>
              </div>
            </div>

            <form
              name="contact"
              method="POST"
              data-netlify="true"
              netlify-honeypot="bot-field"
              onSubmit={handleFormSubmit}
              className="contact-form"
            >
              <input type="hidden" name="form-name" value="contact" />
              <p style={{ display: 'none' }}>
                <label>
                  Don’t fill this out if you’re human: <input name="bot-field" />
                </label>
              </p>

              <h3 className="contact-form__heading">Request a Paid Test Edit or Discovery Call</h3>

              {formSubmitted ? (
                <div className="contact-form__success">
                  ✅ Brief received! I’ll reply within a few hours to kick off your test edit.
                </div>
              ) : (
                <>
                  <label className="form-field">
                    <span>Your Name & Brand</span>
                    <input
                      type="text"
                      name="name"
                      required
                      placeholder="Alex Rivera — GlowLabs DTC"
                    />
                  </label>

                  <label className="form-field">
                    <span>Work Email</span>
                    <input
                      type="email"
                      name="email"
                      required
                      placeholder="alex@glowlabs.com"
                    />
                  </label>

                  <label className="form-field">
                    <span>Ad Format Needed & Monthly Volume</span>
                    <textarea
                      name="message"
                      rows={4}
                      required
                      placeholder="We need 8 hyperrealistic AI UGC reels + 2 Pharmacist Authority VSLs per week..."
                    />
                  </label>

                  <button type="submit" className="btn btn--primary btn--full">
                    Send Creative Brief →
                  </button>
                </>
              )}
            </form>
          </div>
        </section>
      </main>
    </div>
  );
}
