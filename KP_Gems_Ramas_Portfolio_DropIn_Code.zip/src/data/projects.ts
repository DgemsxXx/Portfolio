export type AdCategory =
  | 'All'
  | 'Hyperrealistic AI UGC'
  | 'Authority VSL'
  | '3D Pixar & Claymation'
  | 'Cinematic Product & Motion';

export interface PortfolioProject {
  id: string;
  title: string;
  brand: string;
  folderOrigin: string;
  category: Exclude<AdCategory, 'All'>;
  aspectRatio: '9:16' | '16:9';
  videoUrl: string;
  posterUrl: string;
  primaryMetric: {
    value: string;
    label: string;
  };
  secondaryMetric: {
    value: string;
    label: string;
  };
  hookStrategy: string;
  description: string;
  stackTags: string[];
  featured?: boolean;
}

export const projects: PortfolioProject[] = [
  {
    id: 'venti-absolu-ugc',
    title: 'VENTI ABSOLU — Perfume AI UGC Ad ("Kim" Character Lock)',
    brand: 'VENTI ABSOLU (TikTok Shop)',
    folderOrigin: 'Ultra Realistic Female Influencer UGC',
    category: 'Hyperrealistic AI UGC',
    aspectRatio: '9:16',
    videoUrl: '/videos/venti-absolu-ugc.mp4',
    posterUrl: '/videos/venti-absolu-poster.webp',
    primaryMetric: { value: '4,881+', label: 'TikTok Views' },
    secondaryMetric: { value: '6 Sales', label: '138 Clicks / 3.7K Impr. (7d)' },
    hookStrategy: 'Sensory pattern-interrupt application + immediate social proof',
    description:
      'Selected as an official TikTok Shop Ad (@lumiere_898). Engineered with a reusable character- and product-lock system featuring unretouched matte skin physics and natural vocal pacing.',
    stackTags: ['Higgsfield', 'Nano Banana 2.1', 'ElevenLabs STS', 'CapCut Pro'],
    featured: true,
  },
  {
    id: 'pharmacist-authority-vsl',
    title: 'Pharmacist Authority VSL — Health & Wellness Client Test',
    brand: 'Health & Wellness DTC',
    folderOrigin: "VSL's / Pharmacist AI UGC",
    category: 'Authority VSL',
    aspectRatio: '9:16',
    videoUrl: '/videos/pharmacist-vsl.mp4',
    posterUrl: '/videos/pharmacist-poster.webp',
    primaryMetric: { value: '100% AI', label: 'Character & Voice' },
    secondaryMetric: { value: 'Paid Test', label: 'Client Authority VSL' },
    hookStrategy: 'Medical-authority symptom callout + mechanism reveal + risk-reversal CTA',
    description:
      'Full AI-generated medical authority VSL engineered with clinical credibility, tight mid-roll retention pacing, and dynamic direct-response captions.',
    stackTags: ['Google Flow Omni', 'Nano Banana 2.1', 'Higgsfield', 'HeyGen', 'ElevenLabs'],
    featured: true,
  },
  {
    id: 'arcads-ultrarealistic-test',
    title: '5-Variation Multi-Niche AI UGC Split Test',
    brand: 'Protein Coffee • Lip Treatment • L-Glutathione',
    folderOrigin: 'Arcads test edit',
    category: 'Hyperrealistic AI UGC',
    aspectRatio: '9:16',
    videoUrl: '/videos/arcads-test-edit.mp4',
    posterUrl: '/videos/arcads-test-poster.webp',
    primaryMetric: { value: '5 Angles', label: 'Rapid Hook Matrix' },
    secondaryMetric: { value: '12–24h', label: 'Turnaround Pipeline' },
    hookStrategy: 'Problem-agitation hook matrix + authentic bilabial lip-sync',
    description:
      'Multi-angle direct-response test batch showcasing natural bilabial jaw and lip motion, unretouched matte skin realism, and conversion-focused Speech-to-Speech cadence.',
    stackTags: ['Arcads', 'Veo 3.1', 'Seedance', 'ElevenLabs', 'CapCut Pro'],
    featured: true,
  },
  {
    id: 'resilia-dr-edit',
    title: 'Resilia Direct-Response Video Ad System',
    brand: 'Resilia Health',
    folderOrigin: "VSL's",
    category: 'Authority VSL',
    aspectRatio: '9:16',
    videoUrl: '/videos/resilia-edit.mp4',
    posterUrl: '/videos/resilia-poster.webp',
    primaryMetric: { value: 'High Hold', label: 'Mid-Roll Retention' },
    secondaryMetric: { value: '1080p', label: 'Faststart Master' },
    hookStrategy: 'Visceral problem hook + clinical proof B-roll + urgency offer stack',
    description:
      'High-converting direct-response edit built to maximize 3-second thumbstop and 15-second hold rates through rapid visual pacing and audio sweetening.',
    stackTags: ['Premiere Pro', 'CapCut Pro', 'ElevenLabs', 'Direct-Response Scripting'],
    featured: true,
  },
  {
    id: 'pixar-ai-song-ads',
    title: '3D Pixar-Style Musical Hook & Song Ad',
    brand: 'DTC Brand Concept',
    folderOrigin: '3D Pixar AI song Ads',
    category: '3D Pixar & Claymation',
    aspectRatio: '9:16',
    videoUrl: '/videos/pixar-ai-song-ad.mp4',
    posterUrl: '/videos/pixar-song-poster.webp',
    primaryMetric: { value: 'Custom AI', label: 'Suno Song Hook' },
    secondaryMetric: { value: '100% Lock', label: 'Zero Character Morphing' },
    hookStrategy: 'Earworm custom AI musical hook + expressive 3D character storytelling',
    description:
      'Combines Pixar-inspired 3D character animation with an original Suno AI musical hook to stop the scroll and boost organic shareability.',
    stackTags: ['Google Flow (Veo 3)', 'Suno AI', 'ElevenLabs', 'CapCut Pro'],
  },
  {
    id: 'pixar-dental-meta-ad',
    title: 'Pixar-Style 3D Dental Explainer Ad for Meta',
    brand: 'Dental & Oral Care Concept',
    folderOrigin: '3D pixar style Animation Ad',
    category: '3D Pixar & Claymation',
    aspectRatio: '9:16',
    videoUrl: '/videos/pixar-dental-ad.mp4',
    posterUrl: '/videos/pixar-dental-poster.webp',
    primaryMetric: { value: 'Veo 3', label: 'Character & Scene Lock' },
    secondaryMetric: { value: 'Meta Reels', label: 'Pattern-Interrupt Hook' },
    hookStrategy: '3D character transformation hook + visual benefit demonstration',
    description:
      'Engineered with a strict character- and location-lock workflow in Google Flow (Veo 3) to maintain 100% visual continuity across every scene.',
    stackTags: ['Google Flow (Veo 3)', 'Nano Banana 2.1', 'ElevenLabs', 'CapCut Pro'],
  },
  {
    id: 'sunstick-short-ad',
    title: 'Sunstick Fast-Paced DTC Product Hook Concept',
    brand: 'Skincare / Sun Care DTC',
    folderOrigin: 'Sunstick Short Ad',
    category: 'Cinematic Product & Motion',
    aspectRatio: '9:16',
    videoUrl: '/videos/sunstick-short-ad.mp4',
    posterUrl: '/videos/sunstick-poster.webp',
    primaryMetric: { value: '3-Sec', label: 'Sensory Thumbstop' },
    secondaryMetric: { value: 'DTC Style', label: 'Kinetic Transitions' },
    hookStrategy: 'Immediate texture glide hook + rapid benefit callouts',
    description:
      'High-energy skincare short ad combining studio-grade product B-roll, clean visual transitions, and conversion-focused sound design.',
    stackTags: ['Google Flow Omni', 'Higgsfield', 'CapCut Pro', 'Sound Design'],
  },
  {
    id: 'dough-claymation-ad',
    title: 'Stop-Motion Dough & Claymation Short Ad',
    brand: 'Creative Pattern-Interrupt Concept',
    folderOrigin: 'Dough Animation',
    category: '3D Pixar & Claymation',
    aspectRatio: '9:16',
    videoUrl: '/videos/dough-claymation-ad.mp4',
    posterUrl: '/videos/dough-poster.webp',
    primaryMetric: { value: 'Tactile 3D', label: 'Claymation Aesthetic' },
    secondaryMetric: { value: 'High Hold', label: 'Visual Novelty' },
    hookStrategy: 'Tactile stop-motion pattern interrupt to defeat ad fatigue',
    description:
      'Handcrafted stop-motion claymation look built to stand out immediately in saturated Meta and TikTok feeds.',
    stackTags: ['Google Flow (Veo 3)', 'OpenArt', 'ElevenLabs', 'CapCut Pro'],
  },
  {
    id: 'male-tiktok-ai-ugc',
    title: 'Ultra-Realistic Male Creator TikTok Testimonial',
    brand: 'Men’s Wellness & Lifestyle DTC',
    folderOrigin: 'Male Tiktok AI UGC',
    category: 'Hyperrealistic AI UGC',
    aspectRatio: '9:16',
    videoUrl: '/videos/male-tiktok-ugc.mp4',
    posterUrl: '/videos/male-ugc-poster.webp',
    primaryMetric: { value: 'Native UGC', label: 'iPhone Camera Physics' },
    secondaryMetric: { value: 'Zero-Plastic', label: 'Natural Prosody' },
    hookStrategy: 'Skeptical consumer confession hook + authentic room acoustics',
    description:
      'Authentic male creator testimonial engineered with natural handheld micro-movement, unretouched skin texture, and conversational ElevenLabs delivery.',
    stackTags: ['Higgsfield', 'HeyGen', 'ElevenLabs', 'CapCut Pro'],
  },
  {
    id: 'studio-cinematic-motion',
    title: 'Afnan Supremacy & PUMA Caracal — AI Studio Cinematic Ads',
    brand: 'Afnan Fragrance • PUMA Concept',
    folderOrigin: 'AI studio shot Cinematic & AI Motion graphics',
    category: 'Cinematic Product & Motion',
    aspectRatio: '9:16',
    videoUrl: '/videos/studio-cinematic-ad.mp4',
    posterUrl: '/videos/studio-cinematic-poster.webp',
    primaryMetric: { value: 'Studio B-Roll', label: 'Luxury Lighting Physics' },
    secondaryMetric: { value: 'Motion GFX', label: 'Dynamic Keyframing' },
    hookStrategy: 'High-contrast macro product reveal + kinetic typography',
    description:
      'Commercial studio product cinematography and AI motion graphics for fragrance and footwear campaigns without physical studio overhead.',
    stackTags: ['Google Flow Omni', 'Nano Banana 2.1', 'Higgsfield', 'CapCut Pro'],
  },
];
