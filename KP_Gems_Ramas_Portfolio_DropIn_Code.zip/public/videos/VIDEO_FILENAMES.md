# Quick Video Drop-In Guide (public/videos/)

Your portfolio code is 100% wired and includes graceful fallback cards so the site builds and renders cleanly even before you drop your `.mp4` files in.

When you are ready to add your videos, place your compressed 1080p `.mp4` files and `.webp` posters inside `public/videos/` using these exact filenames:

1. `public/videos/venti-absolu-ugc.mp4` (+ `venti-absolu-poster.webp`) -> From `Ultra Realistic Female Influencer UGC`
2. `public/videos/pharmacist-vsl.mp4` (+ `pharmacist-poster.webp`) -> From `VSL's / Pharmacist AI UGC`
3. `public/videos/arcads-test-edit.mp4` (+ `arcads-test-poster.webp`) -> From `Arcads test edit`
4. `public/videos/resilia-edit.mp4` (+ `resilia-poster.webp`) -> From `VSL's`
5. `public/videos/pixar-ai-song-ad.mp4` (+ `pixar-song-poster.webp`) -> From `3D Pixar AI song Ads`
6. `public/videos/pixar-dental-ad.mp4` (+ `pixar-dental-poster.webp`) -> From `3D pixar style Animation Ad`
7. `public/videos/sunstick-short-ad.mp4` (+ `sunstick-poster.webp`) -> From `Sunstick Short Ad`
8. `public/videos/dough-claymation-ad.mp4` (+ `dough-poster.webp`) -> From `Dough Animation`
9. `public/videos/male-tiktok-ugc.mp4` (+ `male-ugc-poster.webp`) -> From `Male Tiktok AI UGC`
10. `public/videos/studio-cinematic-ad.mp4` (+ `studio-cinematic-poster.webp`) -> From `AI studio shot Cinematic & AI Motion graphics`
